已配置环境：
1. python 包括lint/代码提示/代码自动完成
2. js / 微信小程序环境 tern_for_vim + wxapp.vim
3. NERDTree
4. colorschema  wsniper-light/seou256
