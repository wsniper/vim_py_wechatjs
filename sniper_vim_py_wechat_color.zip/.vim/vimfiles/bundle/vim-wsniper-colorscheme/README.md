# vim-wsniper-colorscheme
vim colorscheme dark and light
